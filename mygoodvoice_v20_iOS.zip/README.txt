
buzztouch v2.0 for iOS
----------------------

Getting Started - YOU MUST HAVE XCODE TO USE THIS SOFTWARE. 4.5 is the latest release, older
releases may work. You also need the latest iOS Software Developer Kit. iOS 6.0 is the
latest release.

You should have downloaded a .zip archive containing an Xcode project and multiple folders.
See the instructions.pdf file included with this download for details about how to compile
this app's source code and run it on the simulator.



